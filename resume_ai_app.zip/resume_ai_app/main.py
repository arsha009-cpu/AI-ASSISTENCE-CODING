
from flask import Flask, render_template, request
import PyPDF2
import re

app = Flask(__name__)

# Extract text from PDF
def extract_text(file):
    text = ""
    try:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            content = page.extract_text()
            if content:
                text += content
    except:
        return ""
    return text.lower()

# AI Analysis
def analyze_resume(text):
    result = []

    if not text:
        return ["❌ Could not read resume properly"]

    # Sections check
    sections = ["education", "experience", "skills", "projects"]
    for sec in sections:
        if sec in text:
            result.append(f"✅ Found: {sec}")
        else:
            result.append(f"❌ Missing: {sec}")

    # Action words
    strong_words = ["developed", "built", "designed", "implemented"]
    if any(word in text for word in strong_words):
        result.append("✅ Strong action words used")
    else:
        result.append("⚠️ Use action words like developed, built")

    # Numbers check
    if re.search(r"\d", text):
        result.append("✅ Has measurable results")
    else:
        result.append("⚠️ Add numbers (e.g., improved 30%)")

    return result


@app.route("/", methods=["GET", "POST"])
def index():
    analysis = None

    if request.method == "POST":
        file = request.files.get("resume")

        if file:
            text = extract_text(file)
            analysis = analyze_resume(text)

    return render_template("index.html", analysis=analysis)


if __name__ == "__main__":
    app.run(debug=True)